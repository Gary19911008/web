<div>
  <div>
    <div
      attr1=""
      attr2=""
      attr3="">
    </div>
    <div attr1="1"
      attr2="2"
      attr3="3">
    </div>
    <div
      attr1="1"
      attr2="2"
      attr3 />
    <div />
  </div>
  <div attr="1"
    attr="2">Foo bar</div>
  <div><div>
    <span />
  </div></div>
  <div />
  {foo &&
    <div />
  }
  {foo.get('foo').foobar &&
    <div
      attr="1">
      {foo}
    </div>
  }
</div>

function () {
  return <div
    attr1=""
    attr2="" />;
  // Foo
}

function () {
  if (foo && bar) {
    func('foobar', function (test) {
      test
    });
  }
}

try {
  statements
} catch (variable) {
  statements
} finally {
  statements
}

foo = "{";

if (foobar) {
  if (foobar === "}") {
    foobar();
  }
}

var foo = [
  {
    bar: 'baz'
  }
];
