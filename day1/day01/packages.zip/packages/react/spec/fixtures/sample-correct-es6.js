import React, { Component, PropTypes } from 'react'; // import react
