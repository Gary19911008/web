# Check list

- Atom version info(`atom --version`)
- vim-mode-plus version.
- Your OS(e.g. macOS Sierra 10.12.3)
- You disabled vim-mode? You cannot use both vim-mode and vim-mode-plus simultaneously.
- Tried to latest stable atom version with latest vim-mode-plus.
- Keybinding issue? [Read this](https://github.com/t9md/atom-vim-mode-plus/wiki/IssueReport#some-keybinding-not-working).
- If you follow [Ideal issue reporting](https://github.com/t9md/atom-vim-mode-plus/wiki/IssueReport#ideal-issue-reporting), it's great!
