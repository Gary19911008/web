module.exports = {
  "env": {
    "browser": true,
    "commonjs": true,
    "es6": true,
    "node": true,
    "jasmine": true,
    "atomtest": true
  },
  "rules": {
    "quotes": "off"
  }
};
